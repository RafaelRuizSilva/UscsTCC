#import secrets;
#token = secrets.token_urlsafe(32)
import pymysql
import os
from pathlib import Path

SMTP_CONFIG = {
    "host": "smtp.gmail.com",
    "port": 587,
    "from": "rafaruizabc@gmail.com",
    "password": "mxlz zayb xmjh wzua",
    "use_tls": True
}

DB_CONFIG = {
    "host": "db", #localhost
    "user": "root",
    "password": "1404",
    "database": "db_uscs_ic",
    "port": 3306,
}

SECRET_KEY = '1o9GCxe2s6Sl3zWMWJkZFf2YKBR7d24RAc8bDuYg6qo'

RABBITMQ_URL = "amqp://guest:guest@rabbitmq:5672/"

DATABASE_URL='mysql+pymysql://root:1404@db:3306/db_uscs_ic'

_THIS_FILE = Path(__file__).resolve()
APP_DIR = _THIS_FILE.parents[2]       # .../app
PROJECT_ROOT = APP_DIR.parent         # .../
TEMPLATE_DIRS = [
    str(PROJECT_ROOT / "templates"),  # raiz/templates
    str(APP_DIR / "templates"),       # app/templates
]
